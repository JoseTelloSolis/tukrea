/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'format', 'hi', {
	label: 'फ़ॉर्मैट',
	panelTitle: 'फ़ॉर्मैट',
	tag_address: 'पता',
	tag_div: 'शीर्षक (DIV)',
	tag_h1: 'शीर्षक 1',
	tag_h2: 'शीर्षक 2',
	tag_h3: 'शीर्षक 3',
	tag_h4: 'शीर्षक 4',
	tag_h5: 'शीर्षक 5',
	tag_h6: 'शीर्षक 6',
	tag_p: 'साधारण',
	tag_pre: 'फ़ॉर्मैटॅड'
} );
