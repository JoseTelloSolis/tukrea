/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'format', 'mn', {
	label: 'Параргафын загвар',
	panelTitle: 'Параргафын загвар',
	tag_address: 'Хаяг',
	tag_div: 'Paragraph (DIV)',
	tag_h1: 'Гарчиг 1',
	tag_h2: 'Гарчиг 2',
	tag_h3: 'Гарчиг 3',
	tag_h4: 'Гарчиг 4',
	tag_h5: 'Гарчиг 5',
	tag_h6: 'Гарчиг 6',
	tag_p: 'Хэвийн',
	tag_pre: 'Formatted'
} );
