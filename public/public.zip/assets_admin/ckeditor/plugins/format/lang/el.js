/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'format', 'el', {
	label: 'Μορφοποίηση',
	panelTitle: 'Μορφοποίηση Παραγράφου',
	tag_address: 'Διεύθυνση',
	tag_div: 'Κανονική (DIV)',
	tag_h1: 'Κεφαλίδα 1',
	tag_h2: 'Κεφαλίδα 2',
	tag_h3: 'Κεφαλίδα 3',
	tag_h4: 'Κεφαλίδα 4',
	tag_h5: 'Κεφαλίδα 5',
	tag_h6: 'Κεφαλίδα 6',
	tag_p: 'Κανονική',
	tag_pre: 'Προ-μορφοποιημένη'
} );
