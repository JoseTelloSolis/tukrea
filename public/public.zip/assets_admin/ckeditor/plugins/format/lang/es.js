/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'format', 'es', {
	label: 'Formato',
	panelTitle: 'Formato',
	tag_address: 'Dirección',
	tag_div: 'Normal (DIV)',
	tag_h1: 'Encabezado 1',
	tag_h2: 'Encabezado 2',
	tag_h3: 'Encabezado 3',
	tag_h4: 'Encabezado 4',
	tag_h5: 'Encabezado 5',
	tag_h6: 'Encabezado 6',
	tag_p: 'Normal',
	tag_pre: 'Con formato'
} );
