/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'format', 'ar', {
	label: 'تنسيق',
	panelTitle: 'تنسيق الفقرة',
	tag_address: 'عنوان',
	tag_div: 'عادي (DIV)',
	tag_h1: 'العنوان 1',
	tag_h2: 'العنوان  2',
	tag_h3: 'العنوان  3',
	tag_h4: 'العنوان  4',
	tag_h5: 'العنوان  5',
	tag_h6: 'العنوان  6',
	tag_p: 'عادي',
	tag_pre: 'منسّق'
} );
