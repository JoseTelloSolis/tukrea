/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'format', 'si', {
	label: 'ආකෘතිය',
	panelTitle: 'චේදයේ ',
	tag_address: 'ලිපිනය',
	tag_div: 'සාමාන්‍ය(DIV)',
	tag_h1: 'ශීර්ෂය 1',
	tag_h2: 'ශීර්ෂය 2',
	tag_h3: 'ශීර්ෂය 3',
	tag_h4: 'ශීර්ෂය 4',
	tag_h5: 'ශීර්ෂය 5',
	tag_h6: 'ශීර්ෂය 6',
	tag_p: 'සාමාන්‍ය',
	tag_pre: 'ආකෘතියන්'
} );
