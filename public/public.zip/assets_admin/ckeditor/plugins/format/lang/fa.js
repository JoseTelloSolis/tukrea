/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'format', 'fa', {
	label: 'قالب',
	panelTitle: 'قالب بند',
	tag_address: 'نشانی',
	tag_div: 'بند',
	tag_h1: 'سرنویس ۱',
	tag_h2: 'سرنویس ۲',
	tag_h3: 'سرنویس ۳',
	tag_h4: 'سرنویس ۴',
	tag_h5: 'سرنویس ۵',
	tag_h6: 'سرنویس ۶',
	tag_p: 'معمولی',
	tag_pre: 'قالب‌دار'
} );
