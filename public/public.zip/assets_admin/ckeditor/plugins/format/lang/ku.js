/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'format', 'ku', {
	label: 'ڕازاندنەوە',
	panelTitle: 'بەشی ڕازاندنەوه',
	tag_address: 'ناونیشان',
	tag_div: '(DIV)-ی ئاسایی',
	tag_h1: 'سەرنووسەی ١',
	tag_h2: 'سەرنووسەی ٢',
	tag_h3: 'سەرنووسەی ٣',
	tag_h4: 'سەرنووسەی ٤',
	tag_h5: 'سەرنووسەی ٥',
	tag_h6: 'سەرنووسەی ٦',
	tag_p: 'ئاسایی',
	tag_pre: 'شێوازکراو'
} );
